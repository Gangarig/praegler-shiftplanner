export default function ProfilePage() {
  return <div>Profile (later)</div>;
}
