export default function HomePage() {
  return <div>Home (simple overview)</div>;
}
